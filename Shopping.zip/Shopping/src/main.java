import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.net.*;
import javax.swing.*;
import javax.swing.*;


public class main extends JFrame{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			new Home();
	}
}
 